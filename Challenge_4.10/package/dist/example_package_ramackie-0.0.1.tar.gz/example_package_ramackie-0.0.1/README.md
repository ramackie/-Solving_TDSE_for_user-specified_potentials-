Thanks for reading me.

This is an example project I'm developing myself.